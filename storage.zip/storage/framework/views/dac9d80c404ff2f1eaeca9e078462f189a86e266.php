<h1>List Products</h1>
<h3><?php echo e($subjudul); ?></h3>

<?php /**PATH /opt/lampp/htdocs/store-app/resources/views/products/index.blade.php ENDPATH**/ ?>